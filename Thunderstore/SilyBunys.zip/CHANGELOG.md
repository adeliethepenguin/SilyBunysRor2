## 1.0.0

- First release
- Hi
- Buny buny buny buny buny

## 1.0.1

- I had the name of the mod wrong in the path

## 1.0.2

- Me too

## 1.0.3

- Um ya. This one is a small nothing though. it shoud work by now.

## 1.0.4

- GRAAAAHHHHHH OK IT WORKS NOW I SWEAR!!!

## 1.0.5

- ok. For real this time. now im no longer being foolish!!! This shoud always work forever. Have fun my friends.

## 1.0.6

- Added config options to turn on and off spawning for each item!! Please use if you are facing lag!!!