# IF YOU HAVE LAG: USE MOD SETTINGS TO DISABLE SPAWNING!!!!!! (i added config stuf ya)
# Silly Bunys by adeliethepenguin

Ya so basically. You get three cute bunny related items. They create more bunnies!!! Fill your inventory with 1 bazilion bunys NOW!! 


Sooo ya. They don't give you stats until you get the LEGENDARY buny but you can use them for printers so can get kind of OP. Anyways, I hope you enjoy. I want to create some more content for this mod and maybe more mods in the future. Please stay tuned.

A description on each item: 

Baby Buny - White:
1% chance to spawn a Baby Buny item on kill.

Cool Buny - Green:
10% chance to spawn a Baby Buny item on kill. 1% chance to spawn a Cool Buny item on kill.

SUPER EPIC BUNY - Red:
ALWAYS get a baby buny on kill. 1% chance to get a baby buny on hit. Every buny you own now grants one max hp!

^ as you can see, this one does not spawn the baby bunys. this is because it gets insanely laggy if you stack them lol. instead it just puts them directly into your inventory (you dont get a popup when it happens but check your inventory for updates). i may add a config option later for people who want to break their games though. 

Also there is french translation since I went to french immersion as a child.
Also the translation is terrible since it has been many years since I've spoken french.

# If you don't know what a bunny is this is what it looks like in real life:
<img width="960" height="1189" alt="image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Oryctolagus_cuniculus_Rcdo.jpg/960px-Oryctolagus_cuniculus_Rcdo.jpg" />